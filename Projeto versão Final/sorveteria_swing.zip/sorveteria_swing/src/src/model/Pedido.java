package model;

public class Pedido {
    private int id;
    private int idCliente;
    private int idSabor;
    private int quantidade;
    private String status;

    public Pedido() {}

    public Pedido(int idCliente, int idSabor, int quantidade) {
        this.idCliente = idCliente;
        this.idSabor = idSabor;
        this.quantidade = quantidade;
        this.status = "PENDENTE";
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getIdCliente() { return idCliente; }
    public void setIdCliente(int idCliente) { this.idCliente = idCliente; }

    public int getIdSabor() { return idSabor; }
    public void setIdSabor(int idSabor) { this.idSabor = idSabor; }

    public int getQuantidade() { return quantidade; }
    public void setQuantidade(int quantidade) { this.quantidade = quantidade; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return id + " - Cliente:" + idCliente + " Sabor:" + idSabor + " qtd:" + quantidade + " status:" + status;
    }
}
