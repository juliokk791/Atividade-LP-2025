package dao;

import db.Conexao;
import model.SaborSorvete;

import java.sql.*;
import java.util.ArrayList;

public class SaborSorveteDAO {

    public void cadastrar(SaborSorvete s) {
        String sql = "INSERT INTO sabor_sorvete (nome, preco, categoria) VALUES (?, ?, ?)";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, s.getNome());
            stmt.setDouble(2, s.getPreco());
            stmt.setString(3, s.getCategoria());

            stmt.executeUpdate();

        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    public ArrayList<SaborSorvete> listar() {
        ArrayList<SaborSorvete> lista = new ArrayList<>();
        String sql = "SELECT * FROM sabor_sorvete";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                SaborSorvete s = new SaborSorvete();
                s.setId(rs.getInt("id"));
                s.setNome(rs.getString("nome"));
                s.setPreco(rs.getDouble("preco"));
                s.setCategoria(rs.getString("categoria"));
                lista.add(s);
            }

        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }

        return lista;
    }
}
