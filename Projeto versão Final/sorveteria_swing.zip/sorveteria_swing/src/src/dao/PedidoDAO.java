package dao;

import db.Conexao;
import model.Pedido;

import java.sql.*;
import java.util.ArrayList;

public class PedidoDAO {

    public void registrar(Pedido p) {
        String sql = "INSERT INTO pedido (id_cliente, id_sabor, quantidade) VALUES (?, ?, ?)";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, p.getIdCliente());
            stmt.setInt(2, p.getIdSabor());
            stmt.setInt(3, p.getQuantidade());

            stmt.executeUpdate();

        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    public ArrayList<Pedido> listar() {
        ArrayList<Pedido> lista = new ArrayList<>();
        String sql = "SELECT * FROM pedido";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Pedido p = new Pedido();
                p.setId(rs.getInt("id"));
                p.setIdCliente(rs.getInt("id_cliente"));
                p.setIdSabor(rs.getInt("id_sabor"));
                p.setQuantidade(rs.getInt("quantidade"));
                p.setStatus(rs.getString("status"));
                lista.add(p);
            }
        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }
        return lista;
    }
}
