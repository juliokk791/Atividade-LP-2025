package ui;

import dao.SaborSorveteDAO;
import model.SaborSorvete;

import javax.swing.*;
import java.awt.*;

public class SaborPanelDialog extends JDialog {

    private JTextField tfNome, tfPreco, tfCategoria;
    private SaborSorveteDAO dao = new SaborSorveteDAO();

    public SaborPanelDialog(Frame owner) {
        super(owner, "Cadastrar Sabor", true);
        setSize(400,250);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout());

        JPanel form = new JPanel(new GridLayout(4,2,5,5));
        form.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        form.add(new JLabel("Nome: "));
        tfNome = new JTextField();
        form.add(tfNome);

        form.add(new JLabel("Preço: "));
        tfPreco = new JTextField();
        form.add(tfPreco);

        form.add(new JLabel("Categoria: "));
        tfCategoria = new JTextField();
        form.add(tfCategoria);

        JButton btnSalvar = new JButton("Salvar");
        btnSalvar.addActionListener(e -> {
            String nome = tfNome.getText().trim();
            String precoStr = tfPreco.getText().trim();
            String cat = tfCategoria.getText().trim();
            if (nome.isEmpty() || precoStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Nome e preço são obrigatórios.");
                return;
            }
            double preco;
            try {
                preco = Double.parseDouble(precoStr);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Preço inválido.");
                return;
            }
            dao.cadastrar(new SaborSorvete(nome, preco, cat));
            JOptionPane.showMessageDialog(this, "Sabor cadastrado com sucesso!");
            dispose();
        });

        add(form, BorderLayout.CENTER);
        add(btnSalvar, BorderLayout.SOUTH);
    }
}
