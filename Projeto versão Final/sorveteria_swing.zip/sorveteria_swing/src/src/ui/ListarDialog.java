package ui;

import dao.ClienteDAO;
import dao.SaborSorveteDAO;
import dao.PedidoDAO;
import model.Cliente;
import model.SaborSorvete;
import model.Pedido;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class ListarDialog extends JDialog {

    private ClienteDAO clienteDAO = new ClienteDAO();
    private SaborSorveteDAO saborDAO = new SaborSorveteDAO();
    private PedidoDAO pedidoDAO = new PedidoDAO();

    public ListarDialog(Frame owner) {
        super(owner, "Listar Dados", true);
        setSize(700,400);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout());

        JTabbedPane tabs = new JTabbedPane();

        JTextArea taClientes = new JTextArea();
        taClientes.setEditable(false);
        JScrollPane spCli = new JScrollPane(taClientes);
        tabs.addTab("Clientes", spCli);

        JTextArea taSabores = new JTextArea();
        taSabores.setEditable(false);
        JScrollPane spSab = new JScrollPane(taSabores);
        tabs.addTab("Sabores", spSab);

        JTextArea taPedidos = new JTextArea();
        taPedidos.setEditable(false);
        JScrollPane spPed = new JScrollPane(taPedidos);
        tabs.addTab("Pedidos", spPed);

        add(tabs, BorderLayout.CENTER);

        // load data
        List<Cliente> clientes = clienteDAO.listar();
        StringBuilder sb = new StringBuilder();
        for (Cliente c : clientes) sb.append(c).append("\n");
        taClientes.setText(sb.toString());

        List<SaborSorvete> sabores = saborDAO.listar();
        sb = new StringBuilder();
        for (SaborSorvete s : sabores) sb.append(s).append("\n");
        taSabores.setText(sb.toString());

        List<Pedido> pedidos = pedidoDAO.listar();
        sb = new StringBuilder();
        for (Pedido p : pedidos) sb.append(p).append("\n");
        taPedidos.setText(sb.toString());
    }
}
