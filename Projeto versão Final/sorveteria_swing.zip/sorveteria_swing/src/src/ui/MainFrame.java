package ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainFrame extends JFrame {

    public MainFrame() {
        super("Sistema Sorveteria");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 450);
        setLocationRelativeTo(null);

        // Painel principal com botões
        JPanel painel = new JPanel();
        painel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(10,10,10,10);

        JLabel titulo = new JLabel("Sistema Sorveteria");
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        c.gridx = 0; c.gridy = 0; c.gridwidth = 2;
        painel.add(titulo, c);

        JButton btnCliente = new JButton("Cadastrar Cliente");
        JButton btnSabor = new JButton("Cadastrar Sabor");
        JButton btnPedido = new JButton("Registrar Pedido");
        JButton btnListar = new JButton("Listar Dados");

        c.gridwidth = 1;
        c.gridx = 0; c.gridy = 1;
        painel.add(btnCliente, c);
        c.gridx = 1; c.gridy = 1;
        painel.add(btnSabor, c);

        c.gridx = 0; c.gridy = 2;
        painel.add(btnPedido, c);
        c.gridx = 1; c.gridy = 2;
        painel.add(btnListar, c);

        add(painel);

        btnCliente.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ClientePanelDialog(MainFrame.this).setVisible(true);
            }
        });

        btnSabor.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new SaborPanelDialog(MainFrame.this).setVisible(true);
            }
        });

        btnPedido.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new PedidoPanelDialog(MainFrame.this).setVisible(true);
            }
        });

        btnListar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ListarDialog(MainFrame.this).setVisible(true);
            }
        });
    }

    public static void main(String[] args) {
        // Opcional: look and feel do sistema
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception e) {}
        SwingUtilities.invokeLater(() -> {
            new MainFrame().setVisible(true);
        });
    }
}
