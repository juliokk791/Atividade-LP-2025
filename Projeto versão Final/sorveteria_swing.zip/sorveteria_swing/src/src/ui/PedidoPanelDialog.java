package ui;

import dao.PedidoDAO;
import dao.ClienteDAO;
import dao.SaborSorveteDAO;
import model.Pedido;
import model.Cliente;
import model.SaborSorvete;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class PedidoPanelDialog extends JDialog {

    private JComboBox<String> cbClientes, cbSabores;
    private JTextField tfQuantidade;
    private PedidoDAO pedidoDAO = new PedidoDAO();
    private ClienteDAO clienteDAO = new ClienteDAO();
    private SaborSorveteDAO saborDAO = new SaborSorveteDAO();

    public PedidoPanelDialog(Frame owner) {
        super(owner, "Registrar Pedido", true);
        setSize(450,220);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout());

        JPanel form = new JPanel(new GridLayout(4,2,5,5));
        form.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        form.add(new JLabel("Cliente (id - nome): "));
        cbClientes = new JComboBox<>();
        form.add(cbClientes);

        form.add(new JLabel("Sabor (id - nome): "));
        cbSabores = new JComboBox<>();
        form.add(cbSabores);

        form.add(new JLabel("Quantidade: "));
        tfQuantidade = new JTextField("1");
        form.add(tfQuantidade);

        JButton btnSalvar = new JButton("Registrar");
        btnSalvar.addActionListener(e -> {
            String cli = (String) cbClientes.getSelectedItem();
            String sab = (String) cbSabores.getSelectedItem();
            if (cli == null || sab == null) {
                JOptionPane.showMessageDialog(this, "Cadastre clientes e sabores antes.");
                return;
            }
            int idCli = Integer.parseInt(cli.split(" - ")[0]);
            int idSab = Integer.parseInt(sab.split(" - ")[0]);
            int qtd;
            try {
                qtd = Integer.parseInt(tfQuantidade.getText().trim());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Quantidade inválida.");
                return;
            }
            pedidoDAO.registrar(new Pedido(idCli, idSab, qtd));
            JOptionPane.showMessageDialog(this, "Pedido registrado!");
            dispose();
        });

        add(form, BorderLayout.CENTER);
        add(btnSalvar, BorderLayout.SOUTH);

        carregarListas();
    }

    private void carregarListas() {
        cbClientes.removeAllItems();
        List<Cliente> clientes = clienteDAO.listar();
        for (Cliente c : clientes) {
            cbClientes.addItem(c.getId() + " - " + c.getNome());
        }

        cbSabores.removeAllItems();
        List<SaborSorvete> sabores = saborDAO.listar();
        for (SaborSorvete s : sabores) {
            cbSabores.addItem(s.getId() + " - " + s.getNome());
        }
    }
}
