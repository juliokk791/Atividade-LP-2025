package ui;

import dao.ClienteDAO;
import model.Cliente;

import javax.swing.*;
import java.awt.*;

public class ClientePanelDialog extends JDialog {

    private JTextField tfNome, tfTel, tfEmail;
    private ClienteDAO dao = new ClienteDAO();

    public ClientePanelDialog(Frame owner) {
        super(owner, "Cadastrar Cliente", true);
        setSize(400,250);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout());

        JPanel form = new JPanel(new GridLayout(4,2,5,5));
        form.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        form.add(new JLabel("Nome: "));
        tfNome = new JTextField();
        form.add(tfNome);

        form.add(new JLabel("Telefone: "));
        tfTel = new JTextField();
        form.add(tfTel);

        form.add(new JLabel("Email: "));
        tfEmail = new JTextField();
        form.add(tfEmail);

        JButton btnSalvar = new JButton("Salvar");
        btnSalvar.addActionListener(e -> {
            String nome = tfNome.getText().trim();
            String tel = tfTel.getText().trim();
            String email = tfEmail.getText().trim();
            if (nome.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Nome é obrigatório.");
                return;
            }
            dao.cadastrar(new Cliente(nome, tel, email));
            JOptionPane.showMessageDialog(this, "Cliente cadastrado com sucesso!");
            dispose();
        });

        add(form, BorderLayout.CENTER);
        add(btnSalvar, BorderLayout.SOUTH);
    }
}
